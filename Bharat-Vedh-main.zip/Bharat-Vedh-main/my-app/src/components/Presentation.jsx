import React from 'react'

function presentation() {
  return (
    <div id='presentaion'>
        <h1>Ayurveda</h1>
        <p>lorem ipsum</p>
      
    </div>
  )
}

export default presentation;